﻿using DATAACCESS;
using REPOSITORIES;
using Services;
using System.Web.Mvc;
using Unity;
using Unity.Mvc5;

namespace FACCBI
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
            var container = new UnityContainer();

            // register all your components with the container here 
            // it is NOT necessary to register your controllers 

            // e.g. container.RegisterType<ITestService, TestService>(); 

            container.RegisterType<IParameterManagement, ParamManagementService>();
            container.RegisterType<IProductMangement, ProductManagementService>();
            container.RegisterType<IMasterEndorsement, MasterEndorsementService>();
            container.RegisterType<ICplCsl,CplCslService >();
            container.RegisterType<IRateTypeMangament, RateTypeManagementService>();
            container.RegisterType<IPOTManagement, POTManagementService>();
            container.RegisterType<IPropertyType, PropertyTypeService>();
            container.RegisterType<IStateManagement, StateManagementService>();
            container.RegisterType<IConnectionFactory, ConnectionFactory>();
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }
    }
}