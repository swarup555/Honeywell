﻿using ENTITIES;
using REPOSITORIES;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace FACCBI.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        IParameterManagement _blogService;
        IProductMangement _ProductServices;
        IMasterEndorsement _MasterEndorsement;
        ICplCsl _CplCSl;
        IRateTypeMangament _RateTypeManagement;
        IPOTManagement _POT;
        IPropertyType _PropertyType;
        IStateManagement _StateManagement;
        public HomeController()
        {

        }
        public HomeController(IParameterManagement blogService, IProductMangement ProductMangement,
                             IMasterEndorsement MasterEndorsement, ICplCsl CplCSl, IRateTypeMangament RateTypeManagement,
                             IPOTManagement POT, IPropertyType PropertyType, IStateManagement StateManagement)
        {
            _blogService = blogService;
            _ProductServices = ProductMangement;
            _MasterEndorsement = MasterEndorsement;
            _CplCSl = CplCSl;
            _RateTypeManagement = RateTypeManagement;
            _POT = POT;
            _PropertyType = PropertyType;
            _StateManagement = StateManagement;
        }
        public ActionResult Index()
        {

            return View();
        }
        public async Task<JsonResult> GetSeries(string isActive)
        {
            ArrayList data = new ArrayList();
            var resultData = await _blogService.GetAllParams(isActive);
            ChartSeries ch = new ChartSeries();
            ch.name = "User";
            ch.data = new List<ChartDATA>();
            ChartDATA objsercur = new ChartDATA();
            objsercur.name = "CURRENCY";
            objsercur.y = resultData.Where(x => x.IsSystemParm == 0 && x.ParamTypeID == 2).ToList().Count;
            objsercur.drilldown = "CurrencyActive";
            ch.data.Add(objsercur);
            ChartDATA objserdate = new ChartDATA();
            objserdate.name = "DATE";
            objserdate.y = resultData.Where(x => x.IsSystemParm == 0 && x.ParamTypeID == 3).ToList().Count;
            objserdate.drilldown = "DateActive";
            ch.data.Add(objserdate);
            ChartDATA objsernum = new ChartDATA();
            objsernum.name = "NUMBER";
            objsernum.y = resultData.Where(x => x.IsSystemParm == 0 && x.ParamTypeID == 5).ToList().Count;
            objsernum.drilldown = "NumActive";
            ch.data.Add(objsernum);
            ChartDATA objsertxt = new ChartDATA();
            objsertxt.name = "TEXT";
            objsertxt.y = resultData.Where(x => x.IsSystemParm == 0 && x.ParamTypeID == 7).ToList().Count;
            objsertxt.drilldown = "TextActive";
            ch.data.Add(objsertxt);
            ChartSeries inch = new ChartSeries();
            inch.name = "System";
            inch.data = new List<ChartDATA>();
            ChartDATA objinsercur = new ChartDATA();
            objinsercur.name = "CURRENCY";
            objinsercur.y = resultData.Where(x => x.IsSystemParm == 1 && x.ParamTypeID == 2).ToList().Count;
            objinsercur.drilldown = "CurrencyInActive";
            inch.data.Add(objinsercur);
            ChartDATA objserindate = new ChartDATA();
            objserindate.name = "DATE";
            objserindate.y = resultData.Where(x => x.IsSystemParm == 1 && x.ParamTypeID == 3).ToList().Count;
            objserindate.drilldown = "InDateActive";
            inch.data.Add(objserindate);
            ChartDATA objserinnum = new ChartDATA();
            objserinnum.name = "NUMBER";
            objserinnum.y = resultData.Where(x => x.IsSystemParm == 1 && x.ParamTypeID == 5).ToList().Count;
            objserinnum.drilldown = "NuminActive";
            inch.data.Add(objserinnum);
            ChartDATA objserintxt = new ChartDATA();
            objserintxt.name = "TEXT";
            objserintxt.y = resultData.Where(x => x.IsSystemParm == 1 && x.ParamTypeID == 7).ToList().Count;
            objserintxt.drilldown = "TextinActive";
            inch.data.Add(objserintxt);
            data.Add(ch);
            data.Add(inch);
            return Json(data, JsonRequestBehavior.AllowGet);
        }
        public async Task<JsonResult> GetProducts(string isActive)
        {
            ArrayList data = new ArrayList();
            var resultData = await _ProductServices.GetAllProducts(isActive);
            var groups = resultData
              .GroupBy(n => n.PolicyCategoryName)
              .Select(n => new
              {
                  MetricName = n.Key,
                  MetricCount = n.Count()
              }
              )
              .OrderBy(n => n.MetricName);
            ChartSeries ch = new ChartSeries();
            ch.name = "Policy Category";
            ch.data = new List<ChartDATA>();
            List<ChartSeriesDrildown> drl = new List<ChartSeriesDrildown>();
            foreach (var item in groups)
            {
                ChartDATA obj = new ChartDATA();
                obj.name = item.MetricName;
                obj.y = item.MetricCount;
                obj.drilldown = item.MetricName;
                ch.data.Add(obj);

                var drldowndata = (from pro in resultData
                                   where pro.PolicyCategoryName== item.MetricName
                                   select new ProductManagement
                                   {
                                       IsActive = pro.IsActive,
                                       PolicyCategoryName = pro.PolicyCategoryName,
                                       PolicyCategoryID = pro.PolicyCategoryID,
                                       PolicyCoverageName = pro.PolicyCoverageName,
                                       PolicyCoverageId = pro.PolicyCoverageId,
                                       PolicyTypeName = pro.PolicyTypeName == null ? "ALL" : pro.PolicyTypeName,
                                       PolicyTypeId = pro.PolicyTypeId,
                                       PolicyName = pro.PolicyName,
                                       PolicyCode = pro.PolicyCode,
                                       PolicyId = pro.PolicyId,
                                   }
                                   ).ToList();
                var groups1 = drldowndata
                 .GroupBy(n => n.PolicyTypeName)
                 .Select(n => new
                 {
                     MetricName = n.Key == null ? "ALL" : n.Key,
                     MetricCount = n.Count()
                 }
                 )
                 .OrderBy(n => n.MetricName);
                ChartSeriesDrildown drl1 = new ChartSeriesDrildown();
                drl1.id = item.MetricName;
                drl1.name = item.MetricName;
                drl1.data = new List<DrillDownData>();
                foreach (var it in groups1)
                {
                    string drill = RandomString(6);
                    DrillDownData objd = new DrillDownData();
                    objd.id = item.MetricName;
                    objd.name = it.MetricName;
                    objd.y = it.MetricCount;
                    objd.drilldown = drill;
                    drl1.data.Add(objd);
                    drl.Add(drl1);
                    var cat = drldowndata.Where(x => x.PolicyTypeName == it.MetricName).ToList();
                    var groups2 = cat
                                    .GroupBy(n => n.PolicyCoverageName)
                                    .Select(n => new
                                    {
                                        MetricName = n.Key == null ? "ALL" : n.Key,
                                        MetricCount = n.Count()
                                    }
                                    )
                                    .OrderBy(n => n.MetricName);
                    ChartSeriesDrildown drl2 = new ChartSeriesDrildown();
                    drl2.id = drill;
                    drl2.name = it.MetricName;
                    drl2.data = new List<DrillDownData>();
                    foreach (var its in groups2)
                    {
                        DrillDownData iops = new DrillDownData();
                        //iops.id = it.MetricName;
                        iops.y = its.MetricCount;
                        iops.drilldown = "";
                        iops.name = its.MetricName;
                        drl2.data.Add(iops);
                    }
                    drl.Add(drl2);
                }

            }
            data.Add(ch);
            data.Add(drl);
            return Json(data, JsonRequestBehavior.AllowGet);
        }
        public  async Task<JsonResult> GetAllEndos()
        {
            ArrayList datas = new ArrayList();
            var data = await _MasterEndorsement.GetAllEndos("1");
            var inctive= await _MasterEndorsement.GetAllEndos("0");
            ChartSeries ch = new ChartSeries();
            ch.name = "Master Endorsement";
            ch.data = new List<ChartDATA>();
            ChartDATA objsercur = new ChartDATA();
            objsercur.name = "ACTIVE";
            objsercur.y = data.ToList().Count;
            objsercur.drilldown = "";
            ch.data.Add(objsercur);
            ChartDATA objserdate = new ChartDATA();
            objserdate.name = "IN ACTIVE";
            objserdate.y = inctive.ToList().Count;
            objserdate.drilldown = "";
            ch.data.Add(objserdate);
            datas.Add(ch);
            return Json(datas, JsonRequestBehavior.AllowGet);
        }
        public async Task<JsonResult> GetAllCpl()
        {
            ArrayList datas = new ArrayList();
            var data = await _CplCSl.GetAllCpls("1");
            var inctive = await _CplCSl.GetAllCpls("0");
            ChartSeries ch = new ChartSeries();
            ch.name = "CPL/CSL";
            ch.data = new List<ChartDATA>();
            ChartDATA objsercur = new ChartDATA();
            objsercur.name = "ACTIVE";
            objsercur.y = data.ToList().Count;
            objsercur.drilldown = "";
            ch.data.Add(objsercur);
            ChartDATA objserdate = new ChartDATA();
            objserdate.name = "IN ACTIVE";
            objserdate.y = inctive.ToList().Count;
            objserdate.drilldown = "";
            ch.data.Add(objserdate);
            datas.Add(ch);
            return Json(datas, JsonRequestBehavior.AllowGet);
        }
        public async Task<JsonResult> GetAllRatetype()
        {
            var data = await _RateTypeManagement.GetAllRateTyes();
            return Json(data.ToList(), JsonRequestBehavior.AllowGet);
        }
        public async Task<JsonResult> GetAllPOT()
        {
            var data = await _POT.GetAllPOTS();
            return Json(data.ToList(), JsonRequestBehavior.AllowGet);
        }
        public async Task<JsonResult> GetAllProperty()
        {
            var data = await _PropertyType.GetAllPropertyTypes();
            return Json(data.ToList(), JsonRequestBehavior.AllowGet);
        }
        public async Task<JsonResult> GetAllStates()
        {
            var data = await _StateManagement.GetAllStates();
            return Json(data.ToList(), JsonRequestBehavior.AllowGet);
        }
        private static Random random = new Random();
        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
        public async Task<JsonResult> BindParams(string param, string paramtype, string isActive)
        {
            var resultData = await _blogService.GetAllParams(isActive);
            int issystempam;
            if (paramtype == "User")
            {
                issystempam = 0;
            }
            else
            {
                issystempam = 1;
            }
            if (param == "CURRENCY")
            {
                resultData = resultData.Where(x => x.IsSystemParm == issystempam && x.ParamTypeID == 2).ToList();
            }
            else if (param == "DATE")
            {
                resultData = resultData.Where(x => x.IsSystemParm == issystempam && x.ParamTypeID == 3).ToList();
            }
            else if (param == "NUMBER")
            {
                resultData = resultData.Where(x => x.IsSystemParm == issystempam && x.ParamTypeID == 5).ToList();
            }
            else if (param == "TEXT")
            {
                resultData = resultData.Where(x => x.IsSystemParm == issystempam && x.ParamTypeID == 7).ToList();
            }
            return Json(resultData, JsonRequestBehavior.AllowGet);
        }
    }
}