﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public class ChartSeries
    {
        public string name
        {
            get;
            set;
        }
        public List<ChartDATA> data
        {
            get;
            set;
        }

    }
    public class ChartSeriesDrildown
    {
        public string id
        {
            get;
            set;
        }
        public string name
        {
            get;
            set;
        }
        public List<DrillDownData> data
        {
            get;
            set;
        }
    }
    public class ChartDATA
    {
        public string id
        {
            get;
            set;
        }
        public string name
        {
            get;
            set;
        }
        public int y
        {
            get;
            set;
        }
        public string drilldown
        {
            get;
            set;
        }
    }
    public class DrillDown
    {
        public string id
        {
            get;
            set;
        }
        public int y
        {
            get;
            set;
        }
        //public string name
        //{
        //    get;
        //    set;
        //}
        //public List<ChartDAT> data
        //{
        //    get;
        //    set;
        //}
    }
    public class DrillDownData
    {
        public string id
        {
            get;
            set;
        }
        public string name
        {
            get;
            set;
        }
        public int y
        {
            get;
            set;
        }
        public string drilldown
        {
            get;
            set;
        }
        //public List<int> data
        //{
        //    get;
        //    set;
        //}
    }

    public class ChartDAT
    {
        public string id
        {
            get;
            set;
        }
        public List<int> data
        {
            get;
            set;
        }
    }
    //public class ChartSeries
    //{
    //    public string name
    //    {
    //        get;
    //        set;
    //    }
    //    public List<Series> Data
    //    {
    //        get;
    //        set;
    //    }
    //    public List<Drilldown> Drildown
    //    {
    //        get;
    //        set;
    //    }
    //}
    //public class Series
    //{
    //    public string name
    //    {
    //        get;
    //        set;
    //    }
    //    public int y
    //    {
    //        get;
    //        set;
    //    }
    //    public string drilldown
    //    {
    //        get;
    //        set;
    //    }
    //}
    //public class Drilldown
    //{
    //    public string id
    //    {
    //        get;
    //        set;
    //    }
    //    public List<ChartDAT> data
    //    {
    //        get;
    //        set;
    //    }
    //}
    //public class ChartDAT
    //{
    //    public string name
    //    {
    //        get;
    //        set;
    //    }
    //    public int y
    //    {
    //        get;
    //        set;
    //    }
    //}
}
