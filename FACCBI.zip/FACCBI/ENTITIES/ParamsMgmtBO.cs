﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public class ParamsMgmtBO
    {
        public int ParamID
        {
            get;
            set;
        }
        public int UWID
        {
            get;
            set;
        }
        public string ParamCode
        {
            get;
            set;
        }
        public string ParamPrompt
        {
            get;
            set;
        }
        public string ParamLabel
        {
            get;
            set;
        }
        public string ParamTypeName
        {
            get;
            set;
        }
        public int ParamTypeID
        {
            get;
            set;
        }
        public int ParamLevel
        {
            get;
            set;
        }
        public int IsActive
        {
            get;
            set;
        }

        public int HasStaticValues
        {
            get;
            set;
        }
        public int IsRequired
        {
            get;
            set;
        }
        public string LastUpdatedDate
        {
            get;
            set;
        }
        public int LastUpdatedByUserID
        {
            get;
            set;
        }

        public int IsSystemParm
        {
            get;
            set; 
        }
        public string Types
        {
            get;
            set;
        }
        public string RoundingOption
        {
            get;
            set;
        }

    }
}
