﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public class POTManangement
    {
        public int POTID
        {
            get;
            set;
        }

        public string POTName
        {
            get;
            set;
        }

        public string RFCName
        {
            get;
            set;
        }

    }
}
