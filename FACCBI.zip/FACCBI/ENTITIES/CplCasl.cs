﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public class CplCsl
    {
        public int CPLFeeMasterID
        {
            get;
            set;
        }

        public string CPLName
        {
            get;
            set;
        }

        public int IsActive
        {
            get;
            set;
        }
    }
}
