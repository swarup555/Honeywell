﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public class MasterEndorsement
    {
        public int EndoID
        {
            get;
            set;
        }
        public string EndoCode
        {
            get;
            set;
        }
        public string EndoName
        {
            get;
            set;
        }
        public int IsActive
        {
            get;
            set;
        }
        public int LastUpdatedByUserID
        {
            get;
            set;
        }
        public int IsMasterEndoIDUsed
        {
            get;
            set;
        }
    }
}
