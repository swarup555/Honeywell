﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public class ChartSeries
    {
        public string name
        {
            get;
            set;
        }
        public List<ChartDATA> data
        {
            get;
            set;
        }
    }
    public class ChartDATA
    {
        public string name
        {
            get;
            set;
        }
        public string y
        {
            get;
            set;
        }
        public string drilldown
        {
            get;
            set;
        }
    }
    public class DrillDown
    {
        public string id
        {
            get;
            set;
        }
        public List<ChartDAT> data
        {
            get;
            set;
        }
    }

    public class ChartDAT
    {
        public string name
        {
            get;
            set;
        }
        public string y
        {
            get;
            set;
        }
    }

}
