﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public class RateTypeMgmt
    {
        public int RateTypeID
        {
            get;
            set;
        }

        public string RateTypeName
        {
            get;
            set;
        }
        public string TypeRT
        {
            get;
            set;
        }
    }
}
