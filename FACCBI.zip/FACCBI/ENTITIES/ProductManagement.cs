﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTITIES
{
    public class ProductManagement
    {
        public int PolicyId
        {
            get;
            set;
        }

        public string PolicyCode
        {
            get;
            set;
        }

        public string PolicyName
        {
            get;
            set;
        }
        public int PolicyTypeId
        {
            get;
            set;
        }
        public string PolicyTypeName
        {
            get;
            set;
        }
        public int PolicyCoverageId
        {
            get;
            set;
        }
        public string PolicyCoverageName
        {
            get;
            set;
        }
        public int IsActive
        {
            get;
            set;
        }
        public int PolicyCategoryID
        {
            get;
            set;
        }
        public string PolicyCategoryName
        {
            get;
            set;
        }
    }
}
